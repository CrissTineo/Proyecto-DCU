﻿using System;
using System.IO;

namespace ServiceLayer
{
    public class EDirectory
    {
        public void CreateDirectory(string directory)
        {
            if (!Directory.Exists(directory) ) 
            {
                Directory.CreateDirectory(directory);
            }
        }                  
    }
}