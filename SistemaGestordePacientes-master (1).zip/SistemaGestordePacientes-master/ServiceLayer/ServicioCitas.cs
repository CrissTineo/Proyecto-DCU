﻿using DBservicios;
using DBservicios.MirrorDB;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace ServiceLayer
{
    public class ServicioCitas
    {
        private DBservicioCitas dBservicioCitas;

        public ServicioCitas(SqlConnection connection)
        {
            dBservicioCitas = new DBservicioCitas(connection);
        }

        public bool AddCitaPaciente(MirrorCitas item)
        {
            return dBservicioCitas.AddDBCitaPaciente(item);
        }
        public bool AddCitaMedico(MirrorCitas item)
        {
            return dBservicioCitas.AddDBCitaMedico(item);
        }
        public bool AddCausa(MirrorCitas item)
        {
            return dBservicioCitas.AddDBCausa(item);
        }
        public bool UpdateEstadoCita(MirrorCitas item)
        {
            return dBservicioCitas.UpdateDBEstadoCita(item);
        }
        public bool DeleteCita(int id)
        {
            return dBservicioCitas.DeleteDBCita(id);
        }
        public int GetlastId()
        {
            return dBservicioCitas.GetDBLastId();
        }
        public MirrorCitas GetCita(int id)
        {
            return dBservicioCitas.GetDBCita(id);
        }
        public DataTable GetAllCitas()
        {
            return dBservicioCitas.GetDBAllCitas();
        }
        public DataTable GetAllCitaForMant()
        {
            return dBservicioCitas.GetDBAllCitasForMant();
        }
        public MirrorCitas GetCitaVentCausa(int id)
        {
            return dBservicioCitas.GetDBCitaVentCausa(id);
        }
    }
}
