﻿using DBservicios.MirrorDB;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DBservicios
{
    public class DBservicioCitas
    {
        private SqlConnection _connection;

        public DBservicioCitas(SqlConnection connection)
        {
            _connection = connection;
        }

        public bool AddDBCitaPaciente(MirrorCitas item)
        {
            SqlCommand command = new SqlCommand("insert into Citas(idPaciente, Estado_de_la_cita)Values(@idpaciente, @estado)",_connection);
            command.Parameters.AddWithValue("@idpaciente", item.idPaciente);
            command.Parameters.AddWithValue("@estado", item.idEstadoDeLaCita);

            return ExecuterSql(command);
        }

        public bool AddDBCitaMedico(MirrorCitas item)
        {
            SqlCommand command = new SqlCommand("update Citas set idMedico=@idmedico where id=@id",_connection);
            command.Parameters.AddWithValue("@id", item.id);
            command.Parameters.AddWithValue("@idmedico", item.idMedico);

            return ExecuterSql(command);
        }
        public bool AddDBCausa(MirrorCitas item)
        {
            SqlCommand command = new SqlCommand("update Citas set Causa_de_la_cita=@causa, Fecha=@fecha, Hora=@hora where id=@id", _connection);
            command.Parameters.AddWithValue("@id", item.id);
            command.Parameters.AddWithValue("@causa", item.CausaDeLaCita);
            command.Parameters.AddWithValue("@fecha", item.Fecha);
            command.Parameters.AddWithValue("@hora", item.Hora);
            command.Parameters.AddWithValue("@estado", item.idEstadoDeLaCita);

            return ExecuterSql(command);
        }
        public bool UpdateDBEstadoCita(MirrorCitas item)
        {
            SqlCommand command = new SqlCommand("update Citas set Estado_de_la_cita=@estado where id=@id", _connection);
            command.Parameters.AddWithValue("@estado", item.idEstadoDeLaCita);
            command.Parameters.AddWithValue("@id", item.id);

            return ExecuterSql(command);
        }
        public bool DeleteDBCita(int id)
        {
            SqlCommand command = new SqlCommand("Delete Citas where id=@id", _connection);
            command.Parameters.AddWithValue("@id", id);

            return ExecuterSql(command);
        }
        public MirrorCitas GetDBCita(int id)
        {            
            try
            {                
                _connection.Open();

                SqlCommand command = new SqlCommand("select a.id, a.idPaciente, a.idMedico, a.Fecha as FechaDeLaCita, a.Hora as HoraDeLaCita, a.Causa_de_la_cita, a.Estado_de_la_cita, b.Nombre as NombrePaciente, c.Nombre as NombreMedico, d.Estado as EstadoDeLaCita from Citas a inner join pacientes b on a.idPaciente = b.id inner join Medicos c on a.idMedico = c.id inner join EstadoCita d on a.Estado_de_la_cita = d.id where a.id=@id", _connection);
                command.Parameters.AddWithValue("@id",id);

                SqlDataReader reader = command.ExecuteReader();

                MirrorCitas mCitas = new MirrorCitas();

                while (reader.Read())
                {
                    mCitas.id = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
                    mCitas.idPaciente = reader.IsDBNull(1) ? 0 : reader.GetInt32(1);
                    mCitas.idMedico = reader.IsDBNull(2) ? 0 : reader.GetInt32(2);
                    mCitas.Fecha = reader.IsDBNull(3) ? "" : reader.GetString(3);
                    mCitas.Hora = reader.IsDBNull(4) ? "" : reader.GetString(4);
                    mCitas.CausaDeLaCita = reader.IsDBNull(5) ? "" : reader.GetString(5);
                    mCitas.idEstadoDeLaCita = reader.IsDBNull(6) ? 0 : reader.GetInt32(6);
                    mCitas.NombrePaciente = reader.IsDBNull(7) ? "" : reader.GetString(7);
                    mCitas.NombreDoctor = reader.IsDBNull(8) ? "" : reader.GetString(8);
                    mCitas.EstadoDeLaCita = reader.IsDBNull(9) ? "" : reader.GetString(9);                        
                }
                reader.Close();
                reader.Dispose();

                _connection.Close();
                return mCitas;

            }
            catch(Exception)
            {
                return null;
            }           
        }
        public MirrorCitas GetDBCitaVentCausa(int id)
        {
            try
            {
                _connection.Open();

                SqlCommand command = new SqlCommand("select a.id, a.idPaciente, a.idMedico, b.Nombre as NombrePaciente, c.Nombre as NombreMedico from Citas a inner join pacientes b on a.idPaciente = b.id inner join Medicos c on a.idMedico = c.id where a.id = @id", _connection);
                command.Parameters.AddWithValue("@id", id);

                SqlDataReader reader = command.ExecuteReader();

                MirrorCitas mCitas = new MirrorCitas();

                while (reader.Read())
                {
                    mCitas.id = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
                    mCitas.idPaciente = reader.IsDBNull(1) ? 0 : reader.GetInt32(1);
                    mCitas.idMedico = reader.IsDBNull(2) ? 0 : reader.GetInt32(2);                    
                    mCitas.NombrePaciente = reader.IsDBNull(3) ? "" : reader.GetString(3);
                    mCitas.NombreDoctor = reader.IsDBNull(4) ? "" : reader.GetString(4);                  
                }
                reader.Close();
                reader.Dispose();

                _connection.Close();
                return mCitas;

            }
            catch (Exception)
            {
                return null;
            }
        }
        public DataTable GetDBAllCitas()
        {           
               SqlDataAdapter query = new SqlDataAdapter("select a.id, a.idPaciente, a.idMedico, a.Fecha as FechaDeLaCita, a.Hora as HoraDeLaCita, a.Causa_de_la_cita, a.Estado_de_la_cita, b.Nombre as NombrePaciente, c.Nombre as NombreMedico, d.Estado as EstadoDeLaCita from Citas a inner join pacientes b on a.idPaciente = b.id inner join Medicos c on a.idMedico = c.id inner join EstadoCita d on a.Estado_de_la_cita = d.id", _connection);
               return LoadData(query);          
        }
        public DataTable GetDBAllCitasForMant()
        {           
               SqlDataAdapter query = new SqlDataAdapter("select a.id, b.Nombre as NombrePaciente, c.Nombre as NombreMedico, a.Fecha as FechaDeLaCita, a.Hora as HoraDeLaCita, a.Causa_de_la_cita,  d.Estado as EstadoDeLaCita, a.Estado_de_la_cita as Estado from Citas a inner join pacientes b on a.idPaciente = b.id inner join Medicos c on a.idMedico = c.id inner join EstadoCita d on a.Estado_de_la_cita = d.id", _connection);
               return LoadData(query); 
        }
        public int GetDBLastId() 
        {
            try
            {
                int lastId = 0;
                _connection.Open();

                SqlCommand command = new SqlCommand("select max(id) as Id from Citas", _connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    lastId = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
                }
                reader.Close();
                reader.Dispose();

                _connection.Close();
                return lastId;
            }
            catch
            {
                return 0;
            }
            
        }

        #region Metodos Privados
        private bool ExecuterSql(SqlCommand command)
        {
            try
            {
                _connection.Open();

                command.ExecuteNonQuery();

                _connection.Close();

                return true;
            }
            catch(Exception)
            {
                return false;
            }
        }
        private DataTable LoadData(SqlDataAdapter query) 
        {
            try
            {
                DataTable data = new DataTable();
                _connection.Open();

                query.Fill(data);

                _connection.Close();

                return data;
            }
            catch
            {
                return null;
            }
        }
        #endregion
    }
}
