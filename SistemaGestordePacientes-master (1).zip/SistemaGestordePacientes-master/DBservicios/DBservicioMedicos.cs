﻿using DBservicios.MirrorDB;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DBservicios
{
    public class DBservicioMedicos
    {
        private SqlConnection _connection;

        public DBservicioMedicos(SqlConnection connection) 
        {
            //trayendo la connection
            _connection = connection;
        }

        public bool AddDBMedico(MirrorMedicos item) 
        {
            SqlCommand command = new SqlCommand("insert into Medicos(Nombre, Apellido, Correo, Telefono, Cedula) Values(@nombre, @apellido, @correo, @telefono, @cedula)",_connection);
            command.Parameters.AddWithValue("@nombre", item.Nombre);
            command.Parameters.AddWithValue("@apellido", item.Apellido);
            command.Parameters.AddWithValue("@correo", item.Correo);
            command.Parameters.AddWithValue("@telefono", item.Telefono);
            command.Parameters.AddWithValue("@cedula", item.Cedula);         

            return ExecuteSQL(command);

        }
        public bool EdiDBtMedico(MirrorMedicos item)
        {
            SqlCommand command = new SqlCommand("update Medicos set Nombre=@nombre, Apellido=@apellido, Correo=@correo, Telefono=@telefono, Cedula=@cedula where id=@id ",_connection);
            command.Parameters.AddWithValue("@nombre", item.Nombre);
            command.Parameters.AddWithValue("@apellido", item.Apellido);
            command.Parameters.AddWithValue("@correo", item.Correo);
            command.Parameters.AddWithValue("@telefono", item.Telefono);
            command.Parameters.AddWithValue("@cedula", item.Cedula);        
            command.Parameters.AddWithValue("@id", item.id);

            return ExecuteSQL(command);
        }
        public bool AddDBPhoto(string destination, int id)
        {
            SqlCommand command = new SqlCommand("update Medicos set ProfilePhoto=@foto where id=@id ", _connection);
          
            command.Parameters.AddWithValue("@foto", destination);
            command.Parameters.AddWithValue("@id", id);

            return ExecuteSQL(command);
        }
        public int GetDBLastId() 
        {
            try
            {
                int lastId = 0;
                _connection.Open();
                SqlCommand command = new SqlCommand("select max(id) as Id from Medicos", _connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    lastId = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);

                }
                reader.Close();
                reader.Dispose();

                _connection.Close();

                return lastId;
            }
            catch
            {
                return 0;
            }
            
        }
        public bool DeleteDBMedico(int id)
        {
            SqlCommand command = new SqlCommand("Delete Medicos where id=@id ",_connection);
            command.Parameters.AddWithValue("@id", id);

            return ExecuteSQL(command);

        }

        public MirrorMedicos GetDBMedico(int id)  
        {
            try
            {
                _connection.Open();
                SqlCommand command = new SqlCommand("Select * from Medicos where id=@id",_connection);
                command.Parameters.AddWithValue("@id", id);

                SqlDataReader reader = command.ExecuteReader();

                MirrorMedicos medico = new MirrorMedicos();

                while (reader.Read())                 
                {
                    medico.id = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
                    medico.Nombre = reader.IsDBNull(1) ? "" : reader.GetString(1);
                    medico.Apellido = reader.IsDBNull(2) ? "" : reader.GetString(2);
                    medico.Correo = reader.IsDBNull(3) ? "" : reader.GetString(3);
                    medico.Telefono = reader.IsDBNull(4) ? "" : reader.GetString(4);
                    medico.Cedula = reader.IsDBNull(5) ? "" : reader.GetString(5);
                    medico.ProfilePhoto = reader.IsDBNull(6) ? "" : reader.GetString(6);
                }
                reader.Close();
                reader.Dispose();
                _connection.Close();

                return medico;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return null;
            }
        }

        public List<MirrorMedicos> GetDBMedicoByCed(string ced)
        {
            try
            {
                _connection.Open();

                SqlCommand query = new SqlCommand("select * from Medicos where Cedula=@cedula", _connection);
                query.Parameters.AddWithValue("@cedula", ced);

                SqlDataReader reader = query.ExecuteReader();

                List<MirrorMedicos> list = new List<MirrorMedicos>();

                while (reader.Read())
                {
                    list.Add(new MirrorMedicos
                    {
                        id = reader.IsDBNull(0) ? 0 : reader.GetInt32(0),
                        Nombre = reader.IsDBNull(1) ? "" : reader.GetString(1),
                        Apellido = reader.IsDBNull(2) ? "" : reader.GetString(2),
                        Correo = reader.IsDBNull(3) ? "" : reader.GetString(3),
                        Telefono = reader.IsDBNull(4) ? "" : reader.GetString(4),
                        Cedula = reader.IsDBNull(5) ? "" : reader.GetString(5),
                        ProfilePhoto = reader.IsDBNull(6) ? "" : reader.GetString(6)
                    });

                }
                reader.Close();
                reader.Dispose();

                _connection.Close();

                return list;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public DataTable GetDBAllMedico() 
        {
            try
            {
                SqlDataAdapter query = new SqlDataAdapter("Select * from Medicos",_connection);

                //utilizando el metodo LoadData
                return LoadData(query);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return null;
            }
        }
        private DataTable LoadData(SqlDataAdapter query) 
        {
                DataTable data = new DataTable();
                _connection.Open();

                query.Fill(data);

                _connection.Close();

                return data;         
        }
        private bool ExecuteSQL(SqlCommand query) 
        {
            try
            {
                _connection.Open();

                query.ExecuteNonQuery();

                _connection.Close();

                return true;
            }
            catch (Exception)
            {                
                return false;
            }
        }
    }
}
