﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBservicios.MirrorDB
{
    public class ResultadoPorCed
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string  Cedula { get; set; }
        public string PruebalLaboratorio { get; set; }     
                       
    }
}
