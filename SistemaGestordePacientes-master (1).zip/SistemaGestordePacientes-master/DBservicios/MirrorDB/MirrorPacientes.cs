﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBservicios.MirrorDB
{
    public class MirrorPacientes
    {
        public int id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string  Telefono { get; set; }
        public string Direccion  { get; set; }
        public string Cedula { get; set; }
        public string FechaDeNacimiento { get; set; }
        public int Fumador { get; set; }
        public string Alergia { get; set; }
        public string ProfilePhoto { get; set; }
    }
}
