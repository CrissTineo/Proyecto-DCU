﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBservicios.MirrorDB
{
    public class TipoDeUsuario
    {
        public int Id { get; set; }
        public string TipoUsuario { get; set; }
    }
}
