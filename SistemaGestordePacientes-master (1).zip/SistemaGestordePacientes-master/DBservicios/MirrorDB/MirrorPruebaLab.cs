﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBservicios.MirrorDB
{
    public class MirrorPruebaLab
    {
        public int id { get; set; }
        public string PruebaDeLab { get; set; }
    }
}
    