﻿using DBservicios.MirrorDB;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DBservicios
{
    public class DBservicioPacientes
    {
        private SqlConnection _connection;
        public DBservicioPacientes(SqlConnection connection)
        {
            _connection = connection;
        }

        public bool AddDBPaciente(MirrorPacientes item)
        {
            SqlCommand command = new SqlCommand("insert into pacientes(Nombre, Apellido, Telefono, Direccion, Cedula, FechaDeNacimiento, idFumador, Alergia)values(@nombre, @apellido, @telefono, @direccion, @cedula, @fecha, @fumador, @alergia)", _connection);
            command.Parameters.AddWithValue("@nombre", item.Nombre);
            command.Parameters.AddWithValue("@apellido", item.Apellido);
            command.Parameters.AddWithValue("@telefono", item.Telefono);
            command.Parameters.AddWithValue("@direccion", item.Direccion);
            command.Parameters.AddWithValue("@cedula", item.Cedula);
            command.Parameters.AddWithValue("@fecha", item.FechaDeNacimiento);
            command.Parameters.AddWithValue("@fumador", item.Fumador);
            command.Parameters.AddWithValue("@alergia", item.Alergia);           

            return ExecuterSql(command);
        }
        public bool EditDBpaciente(MirrorPacientes item)
        {
            SqlCommand command = new SqlCommand("update pacientes set Nombre=@nombre, Apellido=@apellido, Telefono=@telefono, Direccion=@direccion, Cedula=@cedula, FechaDeNacimiento=@fecha, idFumador=@fumador, Alergia=@alergia where id=@id", _connection);
            command.Parameters.AddWithValue("@nombre", item.Nombre);
            command.Parameters.AddWithValue("@apellido", item.Apellido);
            command.Parameters.AddWithValue("@telefono", item.Telefono);
            command.Parameters.AddWithValue("@direccion", item.Direccion);
            command.Parameters.AddWithValue("@cedula", item.Cedula);
            command.Parameters.AddWithValue("@fecha", item.FechaDeNacimiento);
            command.Parameters.AddWithValue("@fumador", item.Fumador);
            command.Parameters.AddWithValue("@alergia", item.Alergia);
            command.Parameters.AddWithValue("@id", item.id);
           

            return ExecuterSql(command);
        }
        public bool DeleteDBpacientes(int id)
        {
            SqlCommand command = new SqlCommand("delete pacientes where id=@id", _connection);
            command.Parameters.AddWithValue("@id", id);

            return ExecuterSql(command);
        }
        public int GetDBLastId()
        {
            try
            {
                int lastId = 0;

                _connection.Open();

                SqlCommand command = new SqlCommand("select max(id) as Id from pacientes", _connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    lastId = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
                }
                reader.Close();
                reader.Dispose();

                _connection.Close();

                return lastId;
            }
            catch
            {
                return 0;
            }
        }
        public bool AddDBPhoto(string destination, int id)
        {
            SqlCommand command = new SqlCommand("update pacientes set ProfilePhoto=@foto where id=@id",_connection);

            command.Parameters.AddWithValue("@foto", destination);
            command.Parameters.AddWithValue("@id", id);

            return ExecuterSql(command);
        }
        public MirrorPacientes GetDBpaciente(int id) 
        {
            try
            {
                _connection.Open();

                SqlCommand query = new SqlCommand("select * from pacientes where id=@id", _connection);
                query.Parameters.AddWithValue("@id", id);

                SqlDataReader reader = query.ExecuteReader();

                MirrorPacientes pacientes = new MirrorPacientes();

                while (reader.Read())
                {
                    pacientes.id = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
                    pacientes.Nombre = reader.IsDBNull(1) ? "" : reader.GetString(1);
                    pacientes.Apellido = reader.IsDBNull(2) ? "" : reader.GetString(2);
                    pacientes.Telefono = reader.IsDBNull(3) ? "" : reader.GetString(3);
                    pacientes.Direccion = reader.IsDBNull(4) ? "" : reader.GetString(4);
                    pacientes.Cedula = reader.IsDBNull(5) ? "" : reader.GetString(5);
                    pacientes.FechaDeNacimiento = reader.IsDBNull(6) ? "" : reader.GetString(6);
                    pacientes.Fumador = reader.IsDBNull(7) ? 0 : reader.GetInt32(7);
                    pacientes.Alergia = reader.IsDBNull(8) ? "" : reader.GetString(8);                   
                    pacientes.ProfilePhoto = reader.IsDBNull(9) ? "" : reader.GetString(9);

                }
                reader.Close();
                reader.Dispose();

                _connection.Close();

                return pacientes;
            }
            catch (Exception)
            {               
                return null;
            }
        }
        public List<MirrorPacientes> GetDBpacienteByCed(string ced)
        {
            try
            {
                _connection.Open();

                SqlCommand query = new SqlCommand("select * from pacientes where Cedula=@cedula", _connection);
                query.Parameters.AddWithValue("@cedula", ced);

                SqlDataReader reader = query.ExecuteReader();

                List<MirrorPacientes> list = new List<MirrorPacientes>();

                while (reader.Read())
                {
                    list.Add(new MirrorPacientes
                    {
                        id = reader.IsDBNull(0) ? 0 : reader.GetInt32(0),
                        Nombre = reader.IsDBNull(1) ? "" : reader.GetString(1),
                        Apellido = reader.IsDBNull(2) ? "" : reader.GetString(2),
                        Telefono = reader.IsDBNull(3) ? "" : reader.GetString(3),
                        Direccion = reader.IsDBNull(4) ? "" : reader.GetString(4),
                        Cedula = reader.IsDBNull(5) ? "" : reader.GetString(5),
                        FechaDeNacimiento = reader.IsDBNull(6) ? "" : reader.GetString(6),
                        Fumador = reader.IsDBNull(7) ? 0 : reader.GetInt32(7),
                        Alergia = reader.IsDBNull(8) ? "" : reader.GetString(8),
                        ProfilePhoto = reader.IsDBNull(9) ? "" : reader.GetString(9)
                    });                   

                }
                reader.Close();
                reader.Dispose();

                _connection.Close();

                return list;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public DataTable GetDBAllPacientes()
        {
            SqlDataAdapter query = new SqlDataAdapter("select a.id, a.Nombre, a.Apellido, a.Telefono, a.Direccion, a.Cedula, a.FechaDeNacimiento, b.Respuesta as Fumador, a.Alergia, a.ProfilePhoto from pacientes a inner join Fumador b on a.idFumador = b.id ", _connection);
            //Utilizando Metodo LoadData
            return LoadData(query);
        }

        #region Metodos Privados

        private bool ExecuterSql(SqlCommand query) 
        {
            try
            {
                _connection.Open();

                query.ExecuteNonQuery();

                _connection.Close();

                return true;

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        private DataTable LoadData(SqlDataAdapter query) 
        {
            try
            {
                DataTable data = new DataTable();

                _connection.Open();

                query.Fill(data);

                _connection.Close();

                return data;
            }
            catch (Exception e) 
            {
                return null;
            }
        }
        #endregion



    }
}
