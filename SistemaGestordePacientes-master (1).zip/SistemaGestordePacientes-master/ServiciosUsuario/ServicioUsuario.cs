﻿using DBservicios;
using DBservicios.MirrorDB;
using System;
using System.Data;
using System.Data.SqlClient;

namespace ServiciosUsuario
{
    public class ServicioUsuario
    {
        private DBservicioUsuarios dBservicioUsuarios;
        public ServicioUsuario(SqlConnection connection) 
        {
            dBservicioUsuarios = new DBservicioUsuarios(connection);
        }        

        public bool AddUsuario(MirrorUsuarios item) 
        {
            return dBservicioUsuarios.AddDBUsuario(item);
        }

        public bool EditUsuario(MirrorUsuarios item) 
        {
            return dBservicioUsuarios.EditDBUsuario(item);
        }

        public bool DeleteUsuario(int id)
        {
            return dBservicioUsuarios.DeleteDBUsuario(id);
        }
        public bool LoginUsu(string usu, string contra) 
        {
            return dBservicioUsuarios.LoginDB(usu, contra);
        }

        public MirrorUsuarios TipoUsu(string usu) 
        {
            return dBservicioUsuarios.GetTipoUsuario(usu);
        }

        public MirrorUsuarios GetUsuario(int id) 
        {
            return dBservicioUsuarios.GetDBUsuario(id);
        }

        public DataTable GetAllUsuarios() 
        {
            return dBservicioUsuarios.GetDBAllUsuario();
        }
    }
}
