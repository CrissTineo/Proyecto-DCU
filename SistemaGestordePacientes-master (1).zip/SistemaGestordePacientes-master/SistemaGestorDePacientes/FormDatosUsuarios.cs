﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DBservicios.MirrorDB;
using ServiciosUsuario;
using SistemaGestorDePacientes.CrossClass;
using SistemaGestorDePacientes.CustomItemCbx;

namespace SistemaGestorDePacientes
{
    public partial class FormDatosUsuarios : Form
    {
        CbxServicio cbxServ;
        private ServicioUsuario servicioUsu;
        MantUsuario mantUsu;
        public FormDatosUsuarios()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionStrings);

            cbxServ = new CbxServicio(sqlConnection);
            servicioUsu = new ServicioUsuario(sqlConnection);
            mantUsu = new MantUsuario();
        }
        #region eventos
        private void FormDatosUsuarios_FormClosing(object sender, FormClosingEventArgs e)
        {
            mantUsu.Show();
        }
        private void BtnAceptar_Click(object sender, EventArgs e)
        {
            CrearUsuario();
        }
        private void FormDatosUsuarios_Load(object sender, EventArgs e)
        {
            LoadCbx();
            EditarUsuario();
        }
        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
            mantUsu.Show();
        }

        #endregion

        #region metodos
        private void LoadCbx() 
        {
            CbxTipoDeUsuario opcionPorDefecto = new CbxTipoDeUsuario
            {
                Text = "Seleccionar",
                Value = null
            };
            CbxTipoUsuario.Items.Add(opcionPorDefecto);

            List<TipoDeUsuario> list = cbxServ.getTipoUsuario();

            foreach (TipoDeUsuario item in list) 
            {
                CbxTipoDeUsuario cbx = new CbxTipoDeUsuario()
                {
                    Text = item.TipoUsuario,
                    Value = item.Id
                };
                CbxTipoUsuario.Items.Add(cbx);
            }
            CbxTipoUsuario.SelectedItem = opcionPorDefecto;
        }
        private void CrearUsuario() //Evaluo primero si el usuario hizo clic en el Dgv, si lo hizo no lo dejo agregar sino editar
        {
            if (CroosIndex.indice == 0)
            {
                MirrorUsuarios usuario = new MirrorUsuarios();
                CbxTipoDeUsuario cbx = CbxTipoUsuario.SelectedItem as CbxTipoDeUsuario;

                if (string.IsNullOrEmpty(TxtNombre.Text))
                {
                    MessageBox.Show("Debe Ingresar un Nombre", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtApellido.Text))
                {
                    MessageBox.Show("Debe Ingresar un Apellido", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtEmail.Text))
                {
                    MessageBox.Show("Debe Ingresar el correo electronico", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtUsuario.Text))
                {
                    MessageBox.Show("Debe Ingresar un nombre de usuario", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtContraseña.Text))
                {
                    MessageBox.Show("Debe Ingresar una contraseña", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtConfContraseña.Text))
                {
                    MessageBox.Show("Debe Ingresar una contraseña para confirmar", "Notificación");
                }
                else if (TxtContraseña.Text != TxtConfContraseña.Text)
                {
                    MessageBox.Show("Las contraseña no coinsiden", "Notificación");
                }
                else if (cbx.Value == null)
                {
                    MessageBox.Show("Debe Seleccionar un tipo de usuario", "Notificación");
                }
                else if (servicioUsu.TipoUsu(TxtUsuario.Text).NombreUsuario == TxtUsuario.Text)
                {
                    MessageBox.Show("Este usuario no esta disponible", "aviso");
                }
                else
                {
                    usuario.Nombre = TxtNombre.Text;
                    usuario.Apellido = TxtApellido.Text;
                    usuario.Correo = TxtEmail.Text;
                    usuario.NombreUsuario = TxtUsuario.Text;
                    usuario.PassW = TxtContraseña.Text;
                    usuario.ConfPassW = TxtConfContraseña.Text;
                    usuario.idTipoUsuario = Convert.ToInt32(cbx.Value);

                    bool result = servicioUsu.AddUsuario(usuario);

                    if (result == true)
                    {
                        MessageBox.Show("Usuario creado con exito", "Notificación");
                        CroosIndex.indice = 0;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo crear el usuario", "Aviso");
                    }
                }
            }
            else if (CroosIndex.indice > 0)
            {
                MirrorUsuarios usuario = new MirrorUsuarios();
                CbxTipoDeUsuario cbx = CbxTipoUsuario.SelectedItem as CbxTipoDeUsuario;
                if (string.IsNullOrEmpty(TxtNombre.Text))
                {
                    MessageBox.Show("Debe Ingresar un Nombre", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtApellido.Text))
                {
                    MessageBox.Show("Debe Ingresar un Apellido", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtEmail.Text))
                {
                    MessageBox.Show("Debe Ingresar el correo electronico", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtUsuario.Text))
                {
                    MessageBox.Show("Debe Ingresar un nombre de usuario", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtContraseña.Text))
                {
                    MessageBox.Show("Debe Ingresar una contraseña", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtConfContraseña.Text))
                {
                    MessageBox.Show("Debe Ingresar una contraseña para confirmar", "Notificación");
                }
                else if (TxtContraseña.Text != TxtConfContraseña.Text)
                {
                    MessageBox.Show("Las contraseña no coinsiden", "Notificación");
                }
                else if (cbx.Value == null)
                {
                    MessageBox.Show("Debe Seleccionar un tipo de usuario", "Notificación");
                }
                else if (servicioUsu.TipoUsu(TxtUsuario.Text).NombreUsuario == TxtUsuario.Text)
                {
                    MessageBox.Show("Este usuario no esta disponible", "aviso");
                }
                else
                {
                    usuario.Nombre = TxtNombre.Text;
                    usuario.Apellido = TxtApellido.Text;
                    usuario.Correo = TxtEmail.Text;
                    usuario.NombreUsuario = TxtUsuario.Text;
                    usuario.PassW = TxtContraseña.Text;
                    usuario.ConfPassW = TxtConfContraseña.Text;
                    usuario.idTipoUsuario = Convert.ToInt32(cbx.Value);
                    usuario.id = CroosIndex.indice;

                    bool result = servicioUsu.EditUsuario(usuario);

                    if (result == true)
                    {
                        MessageBox.Show("Usuario editado con exito", "Notificación");
                        CroosIndex.indice = 0;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo editar el usuario", "Aviso");
                    }
                }
            }
        }
        private void EditarUsuario()
        {
            MirrorUsuarios usuario = servicioUsu.GetUsuario(CroosIndex.indice);
            TxtNombre.Text = usuario.Nombre;
            TxtApellido.Text = usuario.Apellido;
            TxtEmail.Text = usuario.Correo;
            TxtUsuario.Text = usuario.NombreUsuario;
            CbxTipoUsuario.SelectedIndex = usuario.idTipoUsuario;
        }
        #endregion


    }

}
