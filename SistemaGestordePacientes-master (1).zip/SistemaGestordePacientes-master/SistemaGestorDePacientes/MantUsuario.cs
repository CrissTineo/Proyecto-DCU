﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ServiciosUsuario;
using SistemaGestorDePacientes.CrossClass;

namespace SistemaGestorDePacientes
{
    public partial class MantUsuario : Form
    {       
        FormMain main;
        ServicioUsuario servicioUsuarios;
        public MantUsuario()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionStrings);

            main = new FormMain();
            servicioUsuarios = new ServicioUsuario(sqlConnection);
        }
        #region Eventos
        private void volverAtrasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            main.Show();
            this.Close();
        }
        private void MantUsuario_Load(object sender, EventArgs e)
        {
            ListarUsuario();
        }
        private void BtnCrearUsuario_Click(object sender, EventArgs e)
        {
            AddUsuario();
        }
      
        private void BtnDeseleciconar_Click(object sender, EventArgs e)
        {
            Deseleccionar();            
        }
        private void DgvMantUsuarios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            CroosIndex.indice = Convert.ToInt32(DgvMantUsuarios.Rows[e.RowIndex].Cells[0].Value.ToString());            
        }
        private void BtnEditarUsuario_Click(object sender, EventArgs e)
        {
            EditUsuario();
        }
        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            DeleteUsuario();
        }
        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        #endregion

        #region Metodos
        private void AddUsuario() 
        {
            if (CroosIndex.indice == 0)
            {
                FormDatosUsuarios fDatos = new FormDatosUsuarios();
                fDatos.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Ha seleccionado un usuario, haga clic en el boton editar o primero deseleccione para agregar", "Aviso");
            }         
        }
        private void EditUsuario()
        {
            if (CroosIndex.indice>0)
            {
                FormDatosUsuarios fDatos = new FormDatosUsuarios();
                fDatos.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Debe selecionar un usuario para editar", "Notificación");
            }
        }
        private void ListarUsuario()
        {
            DgvMantUsuarios.DataSource = servicioUsuarios.GetAllUsuarios();
            DgvMantUsuarios.ClearSelection();
            CroosIndex.indice = 0;
        }
        private void DeleteUsuario()
        {
            if (CroosIndex.indice > 0)
            {
                DialogResult respuesta = MessageBox.Show("Seguro que desea eliminar este Usuario?", "Aviso", MessageBoxButtons.YesNo);
                if (respuesta == DialogResult.Yes)
                {
                    bool resp = servicioUsuarios.DeleteUsuario(CroosIndex.indice);
                    if (resp == true)
                    {
                        MessageBox.Show("Eliminado con exito", "Notificación");
                        ListarUsuario();
                    }
                    else
                    {
                        MessageBox.Show("Eliminado Cancelado", "Aviso");
                    }
                }
            }
            else 
            {
                MessageBox.Show("Debe seleccionar un usuario");
            }
        }
        private void Deseleccionar() 
        {
            DgvMantUsuarios.ClearSelection();
            CroosIndex.indice = 0;
        }
        #endregion

        
    }
}
