﻿
namespace SistemaGestorDePacientes
{
    partial class VentanaCausaCita
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LBLNombreM = new System.Windows.Forms.Label();
            this.TxtNombreM = new System.Windows.Forms.TextBox();
            this.LblNombreP = new System.Windows.Forms.Label();
            this.TxtNombreP = new System.Windows.Forms.TextBox();
            this.LblFecha = new System.Windows.Forms.Label();
            this.LblHoraCita = new System.Windows.Forms.Label();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnAceptar = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.TxtCausaCita = new System.Windows.Forms.TextBox();
            this.LblCausa = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.MtxtFecha = new System.Windows.Forms.MaskedTextBox();
            this.MtxtHora = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::SistemaGestorDePacientes.Properties.Resources.abstract_geometric_hexagons_shape_medicine_science_concept_background_medical_ico;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.52941F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.52941F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.52941F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.52941F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.882353F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.LBLNombreM, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.TxtNombreM, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.LblNombreP, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.TxtNombreP, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.LblFecha, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.LblHoraCita, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.BtnCancelar, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.BtnAceptar, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.MtxtFecha, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.MtxtHora, 2, 5);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.83012F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.79537F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.687261F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.83012F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(754, 518);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.SetColumnSpan(this.pictureBox1, 2);
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::SistemaGestorDePacientes.Properties.Resources.Artboard_2;
            this.pictureBox1.Location = new System.Drawing.Point(180, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.tableLayoutPanel1.SetRowSpan(this.pictureBox1, 2);
            this.pictureBox1.Size = new System.Drawing.Size(348, 140);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // LBLNombreM
            // 
            this.LBLNombreM.AutoSize = true;
            this.LBLNombreM.BackColor = System.Drawing.Color.Transparent;
            this.LBLNombreM.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.LBLNombreM.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LBLNombreM.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.LBLNombreM.Location = new System.Drawing.Point(3, 205);
            this.LBLNombreM.Name = "LBLNombreM";
            this.LBLNombreM.Size = new System.Drawing.Size(171, 23);
            this.LBLNombreM.TabIndex = 1;
            this.LBLNombreM.Text = "Nombre del Doctor";
            this.LBLNombreM.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // TxtNombreM
            // 
            this.TxtNombreM.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.TxtNombreM.Location = new System.Drawing.Point(180, 202);
            this.TxtNombreM.Name = "TxtNombreM";
            this.TxtNombreM.ReadOnly = true;
            this.TxtNombreM.Size = new System.Drawing.Size(171, 23);
            this.TxtNombreM.TabIndex = 2;
            // 
            // LblNombreP
            // 
            this.LblNombreP.AutoSize = true;
            this.LblNombreP.BackColor = System.Drawing.Color.Transparent;
            this.LblNombreP.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.LblNombreP.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblNombreP.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.LblNombreP.Location = new System.Drawing.Point(357, 182);
            this.LblNombreP.Name = "LblNombreP";
            this.LblNombreP.Size = new System.Drawing.Size(171, 46);
            this.LblNombreP.TabIndex = 3;
            this.LblNombreP.Text = "Nombre del Paciente";
            this.LblNombreP.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // TxtNombreP
            // 
            this.TxtNombreP.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.TxtNombreP.Location = new System.Drawing.Point(534, 202);
            this.TxtNombreP.Name = "TxtNombreP";
            this.TxtNombreP.ReadOnly = true;
            this.TxtNombreP.Size = new System.Drawing.Size(171, 23);
            this.TxtNombreP.TabIndex = 4;
            // 
            // LblFecha
            // 
            this.LblFecha.AutoSize = true;
            this.LblFecha.BackColor = System.Drawing.Color.Transparent;
            this.LblFecha.Dock = System.Windows.Forms.DockStyle.Top;
            this.LblFecha.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblFecha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.LblFecha.Location = new System.Drawing.Point(180, 315);
            this.LblFecha.Name = "LblFecha";
            this.LblFecha.Size = new System.Drawing.Size(171, 23);
            this.LblFecha.TabIndex = 5;
            this.LblFecha.Text = "Fecha de la cita";
            this.LblFecha.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LblHoraCita
            // 
            this.LblHoraCita.AutoSize = true;
            this.LblHoraCita.BackColor = System.Drawing.Color.Transparent;
            this.LblHoraCita.Dock = System.Windows.Forms.DockStyle.Top;
            this.LblHoraCita.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblHoraCita.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.LblHoraCita.Location = new System.Drawing.Point(180, 360);
            this.LblHoraCita.Name = "LblHoraCita";
            this.LblHoraCita.Size = new System.Drawing.Size(171, 23);
            this.LblHoraCita.TabIndex = 7;
            this.LblHoraCita.Text = "Hora de la cita";
            this.LblHoraCita.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.AutoSize = true;
            this.BtnCancelar.BackColor = System.Drawing.Color.Pink;
            this.BtnCancelar.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnCancelar.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnCancelar.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.BtnCancelar.Location = new System.Drawing.Point(180, 445);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(171, 36);
            this.BtnCancelar.TabIndex = 10;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = false;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // BtnAceptar
            // 
            this.BtnAceptar.AutoSize = true;
            this.BtnAceptar.BackColor = System.Drawing.Color.SkyBlue;
            this.BtnAceptar.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnAceptar.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnAceptar.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.BtnAceptar.Location = new System.Drawing.Point(357, 445);
            this.BtnAceptar.Name = "BtnAceptar";
            this.BtnAceptar.Size = new System.Drawing.Size(171, 36);
            this.BtnAceptar.TabIndex = 11;
            this.BtnAceptar.Text = "Crear Cita";
            this.BtnAceptar.UseVisualStyleBackColor = false;
            this.BtnAceptar.Click += new System.EventHandler(this.BtnAceptar_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel1.SetColumnSpan(this.tableLayoutPanel2, 4);
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.TxtCausaCita, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.LblCausa, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 231);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(702, 81);
            this.tableLayoutPanel2.TabIndex = 12;
            // 
            // TxtCausaCita
            // 
            this.TxtCausaCita.Dock = System.Windows.Forms.DockStyle.Top;
            this.TxtCausaCita.Location = new System.Drawing.Point(354, 43);
            this.TxtCausaCita.Name = "TxtCausaCita";
            this.TxtCausaCita.Size = new System.Drawing.Size(345, 23);
            this.TxtCausaCita.TabIndex = 1;
            // 
            // LblCausa
            // 
            this.LblCausa.AutoSize = true;
            this.LblCausa.BackColor = System.Drawing.Color.Transparent;
            this.LblCausa.Dock = System.Windows.Forms.DockStyle.Top;
            this.LblCausa.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblCausa.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.LblCausa.Location = new System.Drawing.Point(3, 40);
            this.LblCausa.Name = "LblCausa";
            this.LblCausa.Size = new System.Drawing.Size(345, 23);
            this.LblCausa.TabIndex = 13;
            this.LblCausa.Text = "Causa de la cita";
            this.LblCausa.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.tableLayoutPanel2.SetColumnSpan(this.label1, 2);
            this.label1.Location = new System.Drawing.Point(5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(692, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "_________________________________________________________________________________" +
    "_________________________________________________________________";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // MtxtFecha
            // 
            this.MtxtFecha.Dock = System.Windows.Forms.DockStyle.Top;
            this.MtxtFecha.Location = new System.Drawing.Point(357, 318);
            this.MtxtFecha.Mask = "00/00/0000";
            this.MtxtFecha.Name = "MtxtFecha";
            this.MtxtFecha.Size = new System.Drawing.Size(171, 23);
            this.MtxtFecha.TabIndex = 13;
            // 
            // MtxtHora
            // 
            this.MtxtHora.Dock = System.Windows.Forms.DockStyle.Top;
            this.MtxtHora.Location = new System.Drawing.Point(357, 363);
            this.MtxtHora.Mask = "00:00";
            this.MtxtHora.Name = "MtxtHora";
            this.MtxtHora.Size = new System.Drawing.Size(171, 23);
            this.MtxtHora.TabIndex = 14;
            // 
            // VentanaCausaCita
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 518);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "VentanaCausaCita";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VentanaCausaCita";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.VentanaCausaCita_FormClosed);
            this.Load += new System.EventHandler(this.VentanaCausaCita_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label LBLNombreM;
        private System.Windows.Forms.TextBox TxtNombreM;
        private System.Windows.Forms.Label LblNombreP;
        private System.Windows.Forms.TextBox TxtNombreP;
        private System.Windows.Forms.Label LblFecha;
        private System.Windows.Forms.Label LblHoraCita;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Button BtnAceptar;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox TxtCausaCita;
        private System.Windows.Forms.Label LblCausa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox MtxtFecha;
        private System.Windows.Forms.MaskedTextBox MtxtHora;
    }
}