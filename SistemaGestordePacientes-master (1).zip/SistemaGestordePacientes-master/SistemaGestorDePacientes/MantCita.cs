﻿using DBservicios.MirrorDB;
using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class MantCita : Form
    {        
        FormMain fMain;
        ServicioCitas servCitas;
        private ServicioRPL servRPL;
        public MantCita()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionStrings);
            
            fMain = new FormMain();
            servCitas = new ServicioCitas(sqlConnection);
            servRPL = new ServicioRPL(sqlConnection);
        }
        #region Eventos
        private void BtnCrearCita_Click(object sender, EventArgs e)
        {                        
            VentanaCitaP vPaciente = new VentanaCitaP();
            vPaciente.Show();
            this.Close();
        }
        private void volverAtrasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fMain.Show();
            this.Close();            
        }
        private void MantCita_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void DgvCitas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            CroosIndex.indice = Convert.ToInt32(DgvCitas.Rows[e.RowIndex].Cells[0].Value.ToString());

            //Id estado de cita para habilitar btn segun corresponda
            int estadoCita = servCitas.GetCita(CroosIndex.indice).idEstadoDeLaCita;

            ActiveBtn(estadoCita);
        }
        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            Delete();
        }
        private void BtnDeseleccionar_Click(object sender, EventArgs e)
        {
            Deseleccion();
        }
        private void BtnConsultar_Click(object sender, EventArgs e)
        {
            VentanaPL ventpl = new VentanaPL();            
            ventpl.Show();          
            this.Close();
        }
        private void BtnConResultados_Click(object sender, EventArgs e)
        {
            VentanaRL ventRl = new VentanaRL();
            ventRl.Show();
            this.Close();
        }
        private void BtnVerResultados_Click(object sender, EventArgs e)
        {
            VentanaVerRes venResult = new VentanaVerRes();
            venResult.Show();
            this.Close();
        }
        #endregion
        #region Metodos
        private void LoadData()
        {
            DgvCitas.DataSource = servCitas.GetAllCitaForMant();
            DgvCitas.ClearSelection();
            CroosIndex.indice = 0;
        }       
        private void ActiveBtn(int estadoCita)
        {
            if (estadoCita == 1)
            {
                BtnConsultar.Visible = true;
                BtnConResultados.Visible = false;
                BtnVerResultados.Visible = false;

            }
            else if (estadoCita == 2)
            {
                BtnConResultados.Visible = true;
                BtnConsultar.Visible = false;
                BtnVerResultados.Visible = false;
            }
            else if (estadoCita == 3)
            {
                BtnVerResultados.Visible = true;
                BtnConsultar.Visible = false;
                BtnConResultados.Visible = false;
            }
        }
        private void Delete()
        {
            if (CroosIndex.indice > 0)
            {
                bool result = servCitas.DeleteCita(CroosIndex.indice);
                DialogResult respuesta = MessageBox.Show("Seguro que desea eliminar esta cita?", "Aviso", MessageBoxButtons.YesNo);
                if (respuesta == DialogResult.Yes)
                {
                    if (result == true)
                    {
                        MessageBox.Show("Cita eliminada con exito", "Notificación");
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo eliminar la cita", "Aviso");
                    }
                }
            }
           
        }
        private void Deseleccion()
        {
            DgvCitas.ClearSelection();
            CroosIndex.indice = 0;
            BtnConsultar.Visible = false;
            BtnConResultados.Visible = false;
            BtnVerResultados.Visible = false;
        }

        #endregion

       
    }
}
