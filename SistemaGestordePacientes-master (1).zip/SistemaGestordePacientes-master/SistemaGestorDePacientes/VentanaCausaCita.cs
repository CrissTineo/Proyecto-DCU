﻿using DBservicios.MirrorDB;
using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class VentanaCausaCita : Form
    {
        
        ServicioCitas servCitas;        
        public VentanaCausaCita()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlconnection = new SqlConnection(connectionStrings);
          
            servCitas = new ServicioCitas(sqlconnection);
        }
        #region Eventos
        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            CancelarBtn();
        }
        private void VentanaCausaCita_Load(object sender, EventArgs e)
        {
            LoadData();            
        }
        private void BtnAceptar_Click(object sender, EventArgs e)
        {
            AddCausa();
        }
        private void VentanaCausaCita_FormClosed(object sender, FormClosedEventArgs e)
        {
            MantCita mantCita = new MantCita();
            mantCita.Show();
        }
        #endregion

        #region Metodos
        private void LoadData()
        {
            int LastId = servCitas.GetlastId();
            CroosIndex.indice = LastId;

            MirrorCitas citas = servCitas.GetCitaVentCausa(LastId);          
            TxtNombreP.Text = citas.NombrePaciente;
            TxtNombreM.Text = citas.NombreDoctor;
        }
        private void AddCausa()
        {
            if (CroosIndex.indice > 0)
            {
                if (string.IsNullOrEmpty(TxtCausaCita.Text))
                {
                    MessageBox.Show("Debe ingresar la causa de la cita", "Aviso");
                }
                else if (string.IsNullOrEmpty(MtxtFecha.Text))
                {
                    MessageBox.Show("Debe digitar la Fecha de la cita", "Aviso");
                }
                else if (string.IsNullOrEmpty(MtxtHora.Text))
                {
                    MessageBox.Show("Debe digitar la hora de la cita", "Aviso");
                }
                else
                {
                    MirrorCitas mCitas = new MirrorCitas();
                    mCitas.CausaDeLaCita = TxtCausaCita.Text;
                    mCitas.Fecha = MtxtFecha.Text;
                    mCitas.Hora = MtxtHora.Text;                    
                    mCitas.id = CroosIndex.indice;

                    bool result = servCitas.AddCausa(mCitas);
                    if (result == true)
                    {
                        MessageBox.Show("Causa y fecha agregado", "Notificación");
                        CroosIndex.indice = 0;
                        
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("No se agrego la causa ni la fecha","Aviso");                       

                    }
                }
              
            }
            
        }
        private void CancelarBtn()
        { 
            servCitas.DeleteCita(CroosIndex.indice);
            CroosIndex.indice = 0;           
            this.Close();
        }
        #endregion

        
    }
}
