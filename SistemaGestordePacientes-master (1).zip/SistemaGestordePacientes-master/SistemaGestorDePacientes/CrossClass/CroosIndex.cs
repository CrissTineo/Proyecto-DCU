﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistemaGestorDePacientes.CrossClass
{
    public static class CroosIndex
    {
        static public int indice;
    }
}
