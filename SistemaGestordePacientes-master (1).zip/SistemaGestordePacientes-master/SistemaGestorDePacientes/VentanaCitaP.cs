﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using DBservicios.MirrorDB;

namespace SistemaGestorDePacientes
{
    public partial class VentanaCitaP : Form
    {
        MantCita mantCita;
        VentanaCitaM vMedico;
        ServicioPacientes servPacientes;
        ServicioCitas servCitas;
        public VentanaCitaP()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionStrings);

            mantCita = new MantCita();
            vMedico = new VentanaCitaM();
            servPacientes = new ServicioPacientes(sqlConnection);
            servCitas = new ServicioCitas(sqlConnection);
        }
        #region Eventos
        private void BtnSiguiente_Click(object sender, EventArgs e)
        {
            AddPaciente();
            
        }
        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            CancelarBtn();
        }
        private void VentanaCitaP_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void DgvVentanaCitaP_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            CroosIndex.indice = Convert.ToInt32(DgvVentanaCitaP.Rows[e.RowIndex].Cells[0].Value.ToString());
            BtnSiguiente.Visible = true;
        }
        private void BtnDeseleccion_Click(object sender, EventArgs e)
        {
            Deseleccion();
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            Buscar();
        }
        #endregion

        #region Metodos 
        private void LoadData()
        {
            if (string.IsNullOrEmpty(TxtbusquedaCedula.Text))
            {
                DgvVentanaCitaP.DataSource = servPacientes.GetAllPacientes();
                DgvVentanaCitaP.ClearSelection();
            }
            else
            {
                DgvVentanaCitaP.DataSource = servPacientes.GetDBpacienteByCed(TxtbusquedaCedula.Text);
                DgvVentanaCitaP.ClearSelection();
            }            
        }

        private void AddPaciente()
        {
            if (CroosIndex.indice > 0)
            {
                int estadoCita = 1;
                MirrorCitas mCitas = new MirrorCitas();
                mCitas.idPaciente = CroosIndex.indice;
                mCitas.idEstadoDeLaCita = estadoCita;

                bool result  = servCitas.AddCitaPaciente(mCitas);
                if (result == true)
                {
                    MessageBox.Show("Paciente añadido");                    
                    vMedico.Show();
                    CroosIndex.indice = 0;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("No se pudo añadir el paciente");
                }
            }
            else
            {
                MessageBox.Show("Debe seleccionar un paciente");
            }
        }
        private void CancelarBtn()
        {
            CroosIndex.indice = 0;
            mantCita.Show();
            this.Close();            
        }
        private void Deseleccion()
        {
            DgvVentanaCitaP.ClearSelection();
            BtnSiguiente.Visible = false;
            CroosIndex.indice = 0;
        }
        private void Buscar()
        {
            if (string.IsNullOrEmpty(TxtbusquedaCedula.Text))
            {
                MessageBox.Show("Debe ingresar la cedula", "Aviso");
            }
            else
            {
                LoadData();
            }
        }
        #endregion

    }
}
