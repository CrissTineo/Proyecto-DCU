﻿
namespace SistemaGestorDePacientes
{
    partial class VentanaPL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.DgvPL = new System.Windows.Forms.DataGridView();
            this.LblPruebaLab = new System.Windows.Forms.Label();
            this.BtnRealizar = new System.Windows.Forms.Button();
            this.BtnDeseleccionar = new System.Windows.Forms.Button();
            this.Btncancelar = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPL)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.BackgroundImage = global::SistemaGestorDePacientes.Properties.Resources.abstract_geometric_hexagons_shape_medicine_science_concept_background_medical_ico;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.375F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.625F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.375F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.625F));
            this.tableLayoutPanel1.Controls.Add(this.DgvPL, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.LblPruebaLab, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnRealizar, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnDeseleccionar, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.Btncancelar, 2, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.22222F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.77778F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(867, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // DgvPL
            // 
            this.DgvPL.AllowUserToAddRows = false;
            this.DgvPL.AllowUserToDeleteRows = false;
            this.DgvPL.AllowUserToResizeColumns = false;
            this.DgvPL.AllowUserToResizeRows = false;
            this.DgvPL.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvPL.BackgroundColor = System.Drawing.Color.MintCream;
            this.DgvPL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel1.SetColumnSpan(this.DgvPL, 3);
            this.DgvPL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvPL.Location = new System.Drawing.Point(118, 129);
            this.DgvPL.Name = "DgvPL";
            this.DgvPL.ReadOnly = true;
            this.tableLayoutPanel1.SetRowSpan(this.DgvPL, 2);
            this.DgvPL.RowTemplate.Height = 25;
            this.DgvPL.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvPL.Size = new System.Drawing.Size(634, 137);
            this.DgvPL.TabIndex = 0;
            this.DgvPL.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvPL_CellClick);
            // 
            // LblPruebaLab
            // 
            this.LblPruebaLab.AutoSize = true;
            this.LblPruebaLab.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.SetColumnSpan(this.LblPruebaLab, 3);
            this.LblPruebaLab.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.LblPruebaLab.Font = new System.Drawing.Font("Calibri", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblPruebaLab.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.LblPruebaLab.Location = new System.Drawing.Point(118, 84);
            this.LblPruebaLab.Name = "LblPruebaLab";
            this.LblPruebaLab.Size = new System.Drawing.Size(634, 42);
            this.LblPruebaLab.TabIndex = 1;
            this.LblPruebaLab.Text = "Pruebas De Laboratorios";
            this.LblPruebaLab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnRealizar
            // 
            this.BtnRealizar.AutoSize = true;
            this.BtnRealizar.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnRealizar.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnRealizar.ForeColor = System.Drawing.Color.SteelBlue;
            this.BtnRealizar.Location = new System.Drawing.Point(521, 272);
            this.BtnRealizar.Name = "BtnRealizar";
            this.BtnRealizar.Size = new System.Drawing.Size(231, 42);
            this.BtnRealizar.TabIndex = 2;
            this.BtnRealizar.Text = "Realizar Prueba";
            this.BtnRealizar.UseVisualStyleBackColor = true;
            this.BtnRealizar.Visible = false;
            this.BtnRealizar.Click += new System.EventHandler(this.BtnRealizar_Click);
            // 
            // BtnDeseleccionar
            // 
            this.BtnDeseleccionar.AutoSize = true;
            this.BtnDeseleccionar.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnDeseleccionar.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnDeseleccionar.ForeColor = System.Drawing.Color.LightSlateGray;
            this.BtnDeseleccionar.Location = new System.Drawing.Point(118, 272);
            this.BtnDeseleccionar.Name = "BtnDeseleccionar";
            this.BtnDeseleccionar.Size = new System.Drawing.Size(224, 42);
            this.BtnDeseleccionar.TabIndex = 3;
            this.BtnDeseleccionar.Text = "Deseleccion";
            this.BtnDeseleccionar.UseVisualStyleBackColor = true;
            this.BtnDeseleccionar.Click += new System.EventHandler(this.BtnDeseleccionar_Click);
            // 
            // Btncancelar
            // 
            this.Btncancelar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Btncancelar.AutoSize = true;
            this.Btncancelar.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Btncancelar.ForeColor = System.Drawing.Color.PaleVioletRed;
            this.Btncancelar.Location = new System.Drawing.Point(348, 272);
            this.Btncancelar.Name = "Btncancelar";
            this.Btncancelar.Size = new System.Drawing.Size(167, 42);
            this.Btncancelar.TabIndex = 4;
            this.Btncancelar.Text = "Cancelar";
            this.Btncancelar.UseVisualStyleBackColor = true;
            this.Btncancelar.Click += new System.EventHandler(this.Btncancelar_Click);
            // 
            // VentanaPL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(867, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "VentanaPL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VentanaPL";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.VentanaPL_FormClosing);
            this.Load += new System.EventHandler(this.VentanaPL_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPL)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView DgvPL;
        private System.Windows.Forms.Label LblPruebaLab;
        private System.Windows.Forms.Button BtnRealizar;
        private System.Windows.Forms.Button BtnDeseleccionar;
        private System.Windows.Forms.Button Btncancelar;
    }
}