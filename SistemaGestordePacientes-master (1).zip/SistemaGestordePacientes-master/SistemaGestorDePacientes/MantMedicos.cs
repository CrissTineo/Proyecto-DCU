﻿using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class MantMedicos : Form
    {
        FormMain main;
        FormDatosMedico formDato;
        ServicioMedicos serMedico;
        public MantMedicos()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionStrings);

            serMedico = new ServicioMedicos(sqlConnection);
            main = new FormMain();
            formDato = new FormDatosMedico();
        }
        #region Eventos    
        private void MantMedicos_Load(object sender, EventArgs e)
        {
            ListarMedicos();
        }
        private void volverAtrásToolStripMenuItem_Click(object sender, EventArgs e)
        {
            main.Show();
            this.Close();
        }       
        private void BtnCrearMedico_Click(object sender, EventArgs e)
        {            
            AddMedico();
        }
        private void BtnEditarMedico_Click(object sender, EventArgs e)
        {
            Editar();
        }
        private void BtnEliminarMedico_Click(object sender, EventArgs e)
        {
            DeleteMedico();
            
        }
        private void BtnDeseleccionar_Click(object sender, EventArgs e)
        {
            Deseleccion();
        }
        private void DgvMedico_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            CroosIndex.indice = Convert.ToInt32(DgvMedico.Rows[e.RowIndex].Cells[0].Value.ToString());
            PbMedico.ImageLocation = serMedico.GetMedico(CroosIndex.indice).ProfilePhoto;
        }
        private void salilrToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #endregion

        #region Metodos
        private void AddMedico()
        {
            if (CroosIndex.indice == 0)
            {                
                formDato.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Ha seleccionado un Medico, haga clic en el boton editar o primero deseleccione para agregar", "Aviso");
            }
        }
        private void Editar()
        {
            if (CroosIndex.indice > 0)
            {
                formDato.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Debe seleccionar un Medico para editar", "Notificación");
            }
        }
        private void DeleteMedico()
        {
            if (CroosIndex.indice > 0)
            {
                DialogResult respuesta = MessageBox.Show("Seguro que desea eliminar este medico?", "Aviso", MessageBoxButtons.YesNo);

                if (respuesta == DialogResult.Yes)
                {
                    bool resp = serMedico.DeleteMedico(CroosIndex.indice);

                    if (resp == true)
                    {
                        MessageBox.Show("Eliminado con exito", "Notificación");
                        Deseleccion();
                        ListarMedicos();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo eliminar el medico", "Aviso");
                    }
                }
            }
            else 
            {
                MessageBox.Show("Debe seleccionar un medico");
            }
        }
        private void ListarMedicos() 
        {
            DgvMedico.DataSource = serMedico.GetAllMedico();
            DgvMedico.ClearSelection();
            CroosIndex.indice = 0;
        }
        private void Deseleccion()
        {
            DgvMedico.ClearSelection();
            CroosIndex.indice = 0;
            PbMedico.ImageLocation = "";
        }
        #endregion

     
    }
}
