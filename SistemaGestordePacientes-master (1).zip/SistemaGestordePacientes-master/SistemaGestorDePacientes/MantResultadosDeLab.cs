﻿using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class MantResultadosDeLab : Form
    {
        private ServicioRPL servicioRPL;
        private int index { get; set; }

        public MantResultadosDeLab()
        {
            InitializeComponent();

            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionStrings);

            servicioRPL = new ServicioRPL(connection);

        }
        #region Eventos
        private void MantResultadosDeLab_Load(object sender, EventArgs e)
        {
            LoadDgv();
        }
        private void volverAtrásToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void MantResultadosDeLab_FormClosing(object sender, FormClosingEventArgs e)
        {
            FormMain fMain = new FormMain();
            fMain.Show();
        }
        private void BtnReportarRes_Click(object sender, EventArgs e)
        {
            FormDatosResultadosLAb fRl = new FormDatosResultadosLAb();
            fRl.Show();
            this.Hide();
        }

        private void DgvMantResultados_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            index = Convert.ToInt32(DgvMantResultados.Rows[e.RowIndex].Cells[0].Value.ToString());
            CroosIndex.indice = index;
            if (CroosIndex.indice > 0)
            {
                BtnReportarRes.Visible = true;
            }

        }
        private void BtnDeseleccionar_Click(object sender, EventArgs e)
        {
            Deseleccionar();
        }
        private void BtnFiltrar_Click(object sender, EventArgs e)
        {
            Buscar();
        }
        #endregion

        #region Metodos
        private void LoadDgv()
        {
            if (string.IsNullOrEmpty(TxtFiltrarCed.Text))
            {
                DgvMantResultados.DataSource = servicioRPL.GetAllRpl();
                DgvMantResultados.ClearSelection();
            }
            else
            {
                DgvMantResultados.DataSource = servicioRPL.GetDBResultPLByCed(TxtFiltrarCed.Text);
                DgvMantResultados.ClearSelection();
            }            
        }
        private void Deseleccionar()
        {
            DgvMantResultados.ClearSelection();
            BtnReportarRes.Visible = false;
            index = 0;
            CroosIndex.indice = 0;
        }
        private void Buscar()
        {
            if (string.IsNullOrEmpty(TxtFiltrarCed.Text))
            {
                MessageBox.Show("Debe ingresar la cedula", "Aviso");
            }
            else
            {
                LoadDgv();
            }


        }
        #endregion

       
    }
}
