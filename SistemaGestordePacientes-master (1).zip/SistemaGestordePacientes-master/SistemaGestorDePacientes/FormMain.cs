﻿using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace SistemaGestorDePacientes
{
    public partial class FormMain : Form
    {
        Thread th;
        public FormMain()
        {
            InitializeComponent();
           
        }       
        #region Eventos
        private void BtnUsuarios_Click(object sender, EventArgs e)
        {
            MantUsuario mantUsuario = new MantUsuario();            
            mantUsuario.Show();
            this.Hide();
        }

        private void BtnMedicos_Click(object sender, EventArgs e)
        {
            MantMedicos mantMedicos = new MantMedicos();
            mantMedicos.Show();
            this.Hide();
        }
        private void cerrarSesionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CerrarSesion();
        }            
     
        private void FormMain_Load(object sender, EventArgs e)
        {
            BtnSegunUsuario();
        }        
      
        private void BtnMantPruebaDeL_Click(object sender, EventArgs e)
        {            
            MantPruebaLaboratorio mantPrueba = new MantPruebaLaboratorio();
            mantPrueba.Show();
            this.Hide();
        }
        private void BtnMantPacientes_Click(object sender, EventArgs e)
        {
            MantPacientes mPacientes = new MantPacientes();
            mPacientes.Show();
            this.Hide();
        }
        private void BtnMantRPL_Click(object sender, EventArgs e)
        {            
            MantResultadosDeLab mResultados = new MantResultadosDeLab();
            mResultados.Show();
            this.Hide();
        }
        private void BtnMantCitas_Click(object sender, EventArgs e)
        {            
            MantCita mCitas = new MantCita();
            mCitas.Show();
            this.Hide();
        }
        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        #endregion

        #region metodos
        private void BtnSegunUsuario()
        {

            if (IdTipoUsuario.IdTipoUsu == 1)
            {
                BtnUsuarios.Visible = true;
                BtnMedicos.Visible = true;
                BtnMantPruebaDeL.Visible = true;
            }
            else if (IdTipoUsuario.IdTipoUsu==2) 
            {
                BtnMantPacientes.Visible = true;
                BtnMantCitas.Visible = true;
                BtnMantRPL.Visible = true;
            }
        }

        private void OpenLogin()
        {
            Application.Run(new Login());
        }

        private void CerrarSesion()
        {
            th = new Thread(OpenLogin);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
            this.Close();
        }

        #endregion

        
    }
}
