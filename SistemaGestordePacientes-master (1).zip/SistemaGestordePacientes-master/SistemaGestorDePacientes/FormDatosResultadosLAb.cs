﻿using DBservicios.MirrorDB;
using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class FormDatosResultadosLAb : Form
    {
        ServicioRPL servRpl;
        public FormDatosResultadosLAb()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionStrings);

            servRpl = new ServicioRPL(connection);

        }
        #region Eventos
        private void BtnFinalizar_Click(object sender, EventArgs e)
        {
            Finalizar();
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
            CroosIndex.indice = 0;
        }

        private void FormDatosResultadosLAb_FormClosing(object sender, FormClosingEventArgs e)
        {
            MantResultadosDeLab mR = new MantResultadosDeLab();
            mR.Show();
        }
        #endregion

        #region Metodos
        private void Finalizar()
        {
            MirrorResultadoPL mRpl = new MirrorResultadoPL();
            mRpl.ResultadoDeLaPrueba = TxtResultados.Text;
            mRpl.idEstadoDeResultado = 2;
            mRpl.id = CroosIndex.indice;

            bool result = servRpl.AddReportePL(mRpl);
            if(result == true)
            {
                MessageBox.Show("Reporte realizado con exito");                
                CroosIndex.indice = 0;
                this.Close();
            }
            else
            {
                MessageBox.Show("No se agregó el reporte", "Aviso");
            }
        }
        #endregion
    }
}
