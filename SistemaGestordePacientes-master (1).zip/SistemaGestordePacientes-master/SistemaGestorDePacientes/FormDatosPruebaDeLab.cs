﻿using DBservicios.MirrorDB;
using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class FormDatosPruebaDeLab : Form
    {
        ServicioPl servicioPl;
        MantPruebaLaboratorio mantPrueba; 
        public FormDatosPruebaDeLab()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionStrings);

            servicioPl = new ServicioPl(sqlConnection);
            mantPrueba = new MantPruebaLaboratorio();
        }
        #region Eventos
        private void BtnAceptar_Click(object sender, EventArgs e)
        {
            AddPl();
        }
        private void BtnCancelar_Click(object sender, EventArgs e)
        {            
            this.Close();
            mantPrueba.Show();
        }
        private void FormDatosPruebaDeLab_Load(object sender, EventArgs e)
        {
            editar();
        }
        #endregion
        #region Metodos

        private void AddPl() 
        {
            if (CroosIndex.indice == 0)//Evaluo si el usuario hizo clic en el Dgv, si hizo clic no lo dejo agregar sino editar
            {
                if (string.IsNullOrEmpty(TxtPruebLab.Text))
                {
                    MessageBox.Show("Debe ingresar una prueba de laboratorio");
                }
                else
                {
                    MirrorPruebaLab prueba = new MirrorPruebaLab();

                    prueba.PruebaDeLab = TxtPruebLab.Text;

                    bool resp = servicioPl.AddPl(prueba);

                    if (resp == true)
                    {
                        MessageBox.Show("Prueba agregada con exito");
                        this.Close();
                        mantPrueba.Show();
                        CroosIndex.indice = 0;
                    }
                }
            }
            else if(CroosIndex.indice > 0)
            {

                MirrorPruebaLab prueba = new MirrorPruebaLab();

                if (string.IsNullOrEmpty(TxtPruebLab.Text))
                {
                    MessageBox.Show("Debe ingresar una prueba de laboratorio");
                }
                else
                {
                    prueba.PruebaDeLab = TxtPruebLab.Text;
                    prueba.id = CroosIndex.indice;

                    bool resp = servicioPl.EditPl(prueba);

                    if (resp == true)
                    {
                        MessageBox.Show("Prueba Editada con exito", "Notificación");

                        this.Close();
                        CroosIndex.indice = 0;
                        mantPrueba.Show();
                    }
                    else
                    {
                        MessageBox.Show("No se edito laprueba", "aviso");
                    }
                }
            }
        }

        private void editar() 
        {   //Rellenar el Txt para editar
            MirrorPruebaLab prueba = servicioPl.GetPl(CroosIndex.indice);
            TxtPruebLab.Text = prueba.PruebaDeLab;
        }


        #endregion

        
    }
}
