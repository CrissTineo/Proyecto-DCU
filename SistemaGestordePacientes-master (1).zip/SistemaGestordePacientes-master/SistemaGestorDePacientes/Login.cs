﻿using ServiciosUsuario;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace SistemaGestorDePacientes
{
    public partial class Login : Form
    {
       Thread th;      
        ServicioUsuario servicioUsuarios;       
        public Login()
        {
            InitializeComponent();

            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionStrings);
            //Inicializando los servicios de usuarios
            servicioUsuarios = new ServicioUsuario(sqlConnection);                    
        }
        #region Eventos
        private void BtnIniciarSesion_Click(object sender, EventArgs e)
        {
            AllowLogin();
        }        
        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
        #endregion
        #region Metodos
        private void AllowLogin()//Requisitos de login
        {
            if (TxtUsuario.Text == "")
            {
                MessageBox.Show("Debe ingresar un usuario");
            }
            else if (TxtContraseña.Text == "")
            {
                MessageBox.Show("Debe ingresar la contraseña");
            }
            else if (servicioUsuarios.LoginUsu(TxtUsuario.Text, TxtContraseña.Text) == true)
            {
                IdTipoUsuario.IdTipoUsu = servicioUsuarios.TipoUsu(TxtUsuario.Text).idTipoUsuario;

                th = new Thread(OpenMain);
                th.SetApartmentState(ApartmentState.STA);
                th.Start();
                this.Close();
            }
            else
            {
                MessageBox.Show("Datos incorrectos");
            }
        }
        private void OpenMain()
        {
            Application.Run(new FormMain());
        }
        #endregion

      
    }
}
