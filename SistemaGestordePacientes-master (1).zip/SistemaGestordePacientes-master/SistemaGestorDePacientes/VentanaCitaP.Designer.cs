﻿
namespace SistemaGestorDePacientes
{
    partial class VentanaCitaP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.DgvVentanaCitaP = new System.Windows.Forms.DataGridView();
            this.BtnSiguiente = new System.Windows.Forms.Button();
            this.LblCedula = new System.Windows.Forms.Label();
            this.TxtbusquedaCedula = new System.Windows.Forms.TextBox();
            this.BtnBuscar = new System.Windows.Forms.Button();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LblVentanaP = new System.Windows.Forms.Label();
            this.BtnDeseleccion = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvVentanaCitaP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::SistemaGestorDePacientes.Properties.Resources.abstract_geometric_hexagons_shape_medicine_science_concept_background_medical_ico;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.90622F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.04442F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.34057F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.70879F));
            this.tableLayoutPanel1.Controls.Add(this.DgvVentanaCitaP, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnSiguiente, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.LblCedula, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.TxtbusquedaCedula, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.BtnBuscar, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.BtnCancelar, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.LblVentanaP, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnDeseleccion, 0, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.90071F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.53901F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.560284F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(910, 564);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // DgvVentanaCitaP
            // 
            this.DgvVentanaCitaP.AllowUserToAddRows = false;
            this.DgvVentanaCitaP.AllowUserToDeleteRows = false;
            this.DgvVentanaCitaP.AllowUserToResizeColumns = false;
            this.DgvVentanaCitaP.AllowUserToResizeRows = false;
            this.DgvVentanaCitaP.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvVentanaCitaP.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DgvVentanaCitaP.BackgroundColor = System.Drawing.Color.MintCream;
            this.DgvVentanaCitaP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel1.SetColumnSpan(this.DgvVentanaCitaP, 2);
            this.DgvVentanaCitaP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvVentanaCitaP.Location = new System.Drawing.Point(138, 283);
            this.DgvVentanaCitaP.MultiSelect = false;
            this.DgvVentanaCitaP.Name = "DgvVentanaCitaP";
            this.DgvVentanaCitaP.ReadOnly = true;
            this.DgvVentanaCitaP.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.tableLayoutPanel1.SetRowSpan(this.DgvVentanaCitaP, 2);
            this.DgvVentanaCitaP.RowTemplate.Height = 25;
            this.DgvVentanaCitaP.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvVentanaCitaP.Size = new System.Drawing.Size(633, 182);
            this.DgvVentanaCitaP.TabIndex = 0;
            this.DgvVentanaCitaP.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvVentanaCitaP_CellClick);
            // 
            // BtnSiguiente
            // 
            this.BtnSiguiente.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnSiguiente.AutoSize = true;
            this.BtnSiguiente.BackColor = System.Drawing.Color.SkyBlue;
            this.BtnSiguiente.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnSiguiente.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.BtnSiguiente.Location = new System.Drawing.Point(593, 471);
            this.BtnSiguiente.Name = "BtnSiguiente";
            this.BtnSiguiente.Size = new System.Drawing.Size(178, 44);
            this.BtnSiguiente.TabIndex = 1;
            this.BtnSiguiente.Text = "Siguiente";
            this.BtnSiguiente.UseVisualStyleBackColor = false;
            this.BtnSiguiente.Visible = false;
            this.BtnSiguiente.Click += new System.EventHandler(this.BtnSiguiente_Click);
            // 
            // LblCedula
            // 
            this.LblCedula.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.LblCedula.AutoSize = true;
            this.LblCedula.BackColor = System.Drawing.Color.Transparent;
            this.LblCedula.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblCedula.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.LblCedula.Location = new System.Drawing.Point(224, 215);
            this.LblCedula.Name = "LblCedula";
            this.LblCedula.Size = new System.Drawing.Size(226, 29);
            this.LblCedula.TabIndex = 3;
            this.LblCedula.Text = "Busqueda Por Cédula";
            // 
            // TxtbusquedaCedula
            // 
            this.TxtbusquedaCedula.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtbusquedaCedula.Location = new System.Drawing.Point(138, 254);
            this.TxtbusquedaCedula.Name = "TxtbusquedaCedula";
            this.TxtbusquedaCedula.Size = new System.Drawing.Size(312, 23);
            this.TxtbusquedaCedula.TabIndex = 2;
            // 
            // BtnBuscar
            // 
            this.BtnBuscar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.BtnBuscar.BackColor = System.Drawing.SystemColors.Control;
            this.BtnBuscar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnBuscar.Location = new System.Drawing.Point(456, 254);
            this.BtnBuscar.Name = "BtnBuscar";
            this.BtnBuscar.Size = new System.Drawing.Size(88, 23);
            this.BtnBuscar.TabIndex = 4;
            this.BtnBuscar.Text = "Buscar";
            this.BtnBuscar.UseVisualStyleBackColor = false;
            this.BtnBuscar.Click += new System.EventHandler(this.BtnBuscar_Click);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.AutoSize = true;
            this.BtnCancelar.BackColor = System.Drawing.Color.Pink;
            this.BtnCancelar.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnCancelar.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.BtnCancelar.Location = new System.Drawing.Point(138, 471);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(178, 44);
            this.BtnCancelar.TabIndex = 5;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = false;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::SistemaGestorDePacientes.Properties.Resources.Artboard_2;
            this.pictureBox1.Location = new System.Drawing.Point(138, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(312, 156);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // LblVentanaP
            // 
            this.LblVentanaP.AutoSize = true;
            this.LblVentanaP.BackColor = System.Drawing.Color.Transparent;
            this.LblVentanaP.Dock = System.Windows.Forms.DockStyle.Right;
            this.LblVentanaP.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblVentanaP.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.LblVentanaP.Location = new System.Drawing.Point(470, 0);
            this.LblVentanaP.Name = "LblVentanaP";
            this.LblVentanaP.Size = new System.Drawing.Size(301, 162);
            this.LblVentanaP.TabIndex = 7;
            this.LblVentanaP.Text = "Seleccion de paciente";
            this.LblVentanaP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnDeseleccion
            // 
            this.BtnDeseleccion.AutoSize = true;
            this.BtnDeseleccion.Dock = System.Windows.Forms.DockStyle.Right;
            this.BtnDeseleccion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnDeseleccion.Location = new System.Drawing.Point(46, 283);
            this.BtnDeseleccion.Name = "BtnDeseleccion";
            this.BtnDeseleccion.Size = new System.Drawing.Size(86, 88);
            this.BtnDeseleccion.TabIndex = 8;
            this.BtnDeseleccion.Text = "Deseleccion";
            this.BtnDeseleccion.UseVisualStyleBackColor = true;
            this.BtnDeseleccion.Click += new System.EventHandler(this.BtnDeseleccion_Click);
            // 
            // VentanaCitaP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 564);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "VentanaCitaP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VentanaCitaP";
            this.Load += new System.EventHandler(this.VentanaCitaP_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvVentanaCitaP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView DgvVentanaCitaP;
        private System.Windows.Forms.Button BtnSiguiente;
        private System.Windows.Forms.Label LblCedula;
        private System.Windows.Forms.TextBox TxtbusquedaCedula;
        private System.Windows.Forms.Button BtnBuscar;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label LblVentanaP;
        private System.Windows.Forms.Button BtnDeseleccion;
    }
}