﻿using DBservicios.MirrorDB;
using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class VentanaRL : Form
    {
        ServicioRPL servRPL;
        ServicioCitas servCita;
        public VentanaRL()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionStrings);

            servRPL = new ServicioRPL(connection);
            servCita = new ServicioCitas(connection);
        }
        #region Eventos
        private void VentanaRL_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void VentanaRL_FormClosing(object sender, FormClosingEventArgs e)
        {
            MantCita mCita = new MantCita();
            mCita.Show();
        }
        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void DgvRl_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = 0;
            index = Convert.ToInt32(DgvRl.Rows[e.RowIndex].Cells[0].Value.ToString());
            if (index > 0)
            {
                BtnCompletar.Visible = true;
                BtnDeseleccionar.Visible = true;
            }
        }
        private void BtnCompletar_Click(object sender, EventArgs e)
        {
            Completar();
        }
        private void BtnDeseleccionar_Click(object sender, EventArgs e)
        {
            Deseleccion();
        }
        #endregion

        #region Metodos
        private void LoadData()
        {
            DgvRl.DataSource = servRPL.GetAllRpl();
            DgvRl.ClearSelection();
        }
        private void Deseleccion()
        {
            DgvRl.ClearSelection();
            BtnCompletar.Visible = false;
            BtnDeseleccionar.Visible = false;
        }
        private void Completar()
        {
            MirrorCitas mCita = new MirrorCitas();
            mCita.idEstadoDeLaCita = 3;
            mCita.id = CroosIndex.indice;

            bool result = servCita.UpdateEstadoCita(mCita);
            if(result == true)
            {
                MessageBox.Show("Cita completada");
            }
            else
            {
                MessageBox.Show("No se pudo completar la cita");                    
            }

            this.Close();

        }
        #endregion

        
    }
}
